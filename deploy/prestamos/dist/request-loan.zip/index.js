"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/request-loan.ts
var request_loan_exports = {};
__export(request_loan_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(request_loan_exports);

// src/domain.ts
var import_node_crypto = require("node:crypto");
var import_lib_dynamodb2 = require("@aws-sdk/lib-dynamodb");

// src/shared.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var env = {
  natillerasTable: process.env.NATILLERAS_TABLE || "natillera-registration",
  recordsTable: process.env.NATILLERA_RECORDS_TABLE || "natillera-records",
  loansTable: process.env.LOAN_REQUESTS_TABLE || "natillera-loan-request",
  authorIndex: process.env.LOAN_AUTHOR_INDEX || "author-index",
  natilleraIndex: process.env.LOAN_NATILLERA_INDEX || "natillera-index",
  // Interés por cuota sobre el saldo, en puntos básicos (100 = 1 %), igual que el modo demo del front.
  rateBps: BigInt(process.env.LOAN_RATE_BPS || "100"),
  maxInstallments: Number(process.env.LOAN_MAX_INSTALLMENTS || "12")
};
var dynamo = import_lib_dynamodb.DynamoDBDocumentClient.from(new import_client_dynamodb.DynamoDBClient({ region: process.env.AWS_REGION }), {
  marshallOptions: { removeUndefinedValues: true }
});
var HttpError = class extends Error {
  constructor(statusCode, error, message) {
    super(message);
    this.statusCode = statusCode;
    this.error = error;
  }
};
var json = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(body)
});
var isProxy = () => process.env.INTEGRATION_MODE !== "vtl";
var withErrors = (fn) => async (event) => {
  let status;
  let body;
  try {
    const result = await fn(event);
    return isProxy() ? json(200, result) : result;
  } catch (error) {
    if (error instanceof HttpError) {
      status = error.statusCode;
      body = { error: error.error, message: error.message };
    } else {
      console.log("Unhandled error", error);
      status = 500;
      body = { error: "InternalError", message: "Unexpected error" };
    }
  }
  if (isProxy()) return json(status, body);
  throw new Error(`[${status}] ${JSON.stringify(body)}`);
};
var currentIdentity = (event) => {
  let username;
  let sub;
  if (isProxy()) {
    const authorizer = event?.requestContext?.authorizer ?? {};
    const claims = authorizer.jwt?.claims ?? authorizer.claims ?? {};
    username = claims.username ?? claims["cognito:username"];
    sub = claims.sub;
  } else {
    username = event?.auth?.username;
    sub = event?.auth?.sub;
  }
  if (typeof username !== "string" || !username) throw new HttpError(401, "Unauthorized", "Missing username claim");
  return { username, sub: typeof sub === "string" && sub ? sub : void 0 };
};
var parseBody = (event) => {
  if (!isProxy()) {
    return event?.body && typeof event.body === "object" && !Array.isArray(event.body) ? event.body : {};
  }
  if (!event?.body) return {};
  try {
    const raw = event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body;
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    throw new HttpError(400, "BadRequest", "Body must be valid JSON");
  }
};

// src/domain.ts
var parseValue = (raw) => {
  if (typeof raw !== "string" || !/^[1-9]\d{0,15}$/.test(raw)) {
    throw new HttpError(400, "InvalidAmount", "value must be a positive integer string in minor units");
  }
  return BigInt(raw);
};
var parseInstallments = (raw) => {
  const n = typeof raw === "string" ? Number(raw) : raw;
  if (typeof n !== "number" || !Number.isInteger(n) || n < 1 || n > env.maxInstallments) {
    throw new HttpError(400, "InvalidInstallments", `installments must be an integer between 1 and ${env.maxInstallments}`);
  }
  return n;
};
var parseAsset = (assetCode, assetScale) => {
  const scale = typeof assetScale === "string" ? Number(assetScale) : assetScale;
  if (typeof assetCode !== "string" || !/^[A-Z]{3}$/.test(assetCode) || typeof scale !== "number" || !Number.isInteger(scale) || scale < 0 || scale > 9) {
    throw new HttpError(400, "InvalidAmount", "assetCode (3 letters) and assetScale (0-9) are required");
  }
  return { assetCode, assetScale: scale };
};
var getNatillera = async (natilleraId) => {
  const { Item } = await dynamo.send(new import_lib_dynamodb2.GetCommand({ TableName: env.natillerasTable, Key: { natilleraId } }));
  return Item ?? null;
};
var availableFund = async (n) => {
  let total = 0n;
  let ExclusiveStartKey;
  do {
    const page = await dynamo.send(
      new import_lib_dynamodb2.QueryCommand({
        TableName: env.recordsTable,
        KeyConditionExpression: "natilleraId = :n",
        ExpressionAttributeValues: { ":n": n.natilleraId },
        ExclusiveStartKey
      })
    );
    for (const r of page.Items ?? []) {
      if (r.amount?.assetCode === n.assetCode && r.amount?.assetScale === n.assetScale) total += BigInt(r.amount.value);
    }
    ExclusiveStartKey = page.LastEvaluatedKey;
  } while (ExclusiveStartKey);
  return total - BigInt(n.disbursedTotal ?? "0");
};
var toRequest = (i) => ({
  requestId: i.requestId,
  natilleraId: i.natilleraId,
  requesterName: i.author,
  amount: i.amount,
  installments: i.installments,
  repaymentAuthorized: Boolean(i.repaymentAuthorized),
  status: i.status,
  createdAt: i.createdAt
});
var queryLoans = async (indexName, field, value) => {
  const items = [];
  let ExclusiveStartKey;
  do {
    const page = await dynamo.send(
      new import_lib_dynamodb2.QueryCommand({
        TableName: env.loansTable,
        IndexName: indexName,
        KeyConditionExpression: `${field} = :v`,
        ExpressionAttributeValues: { ":v": value },
        ExclusiveStartKey
      })
    );
    items.push(...page.Items ?? []);
    ExclusiveStartKey = page.LastEvaluatedKey;
  } while (ExclusiveStartKey);
  return items.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
};
var isActive = (i) => i.status === "pending" || i.status === "approved" && (i.paidCount ?? 0) < i.installments;
var requestLoan = async (username, body) => {
  if (typeof body.natilleraId !== "string" || !body.natilleraId) throw new HttpError(400, "BadRequest", "natilleraId is required");
  const value = parseValue(body.value);
  const installments = parseInstallments(body.installments);
  const asset = parseAsset(body.assetCode, body.assetScale);
  const natillera = await getNatillera(body.natilleraId);
  if (!natillera) throw new HttpError(404, "NatilleraNotFound", "Natillera not found");
  if (!natillera.integrants.includes(username)) throw new HttpError(403, "Forbidden", "You are not a member of this natillera");
  if (asset.assetCode !== natillera.assetCode || asset.assetScale !== natillera.assetScale) {
    throw new HttpError(400, "InvalidAmount", `Loans are in the fund currency (${natillera.assetCode}, scale ${natillera.assetScale})`);
  }
  const mine = await queryLoans(env.authorIndex, "author", username);
  if (mine.some((i) => i.natilleraId === natillera.natilleraId && isActive(i))) {
    throw new HttpError(409, "LoanAlreadyActive", "You already have a loan request or an active loan in this natillera");
  }
  if (value > await availableFund(natillera)) throw new HttpError(409, "InsufficientFunds", "The fund does not have that much money");
  const item = {
    requestId: (0, import_node_crypto.randomUUID)(),
    natilleraId: natillera.natilleraId,
    author: username,
    amount: { value: value.toString(), ...asset },
    installments,
    status: "pending",
    repaymentAuthorized: false,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  await dynamo.send(new import_lib_dynamodb2.PutCommand({ TableName: env.loansTable, Item: item, ConditionExpression: "attribute_not_exists(requestId)" }));
  return toRequest(item);
};

// src/request-loan.ts
var handler = withErrors(async (event) => requestLoan(currentIdentity(event).username, parseBody(event)));
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
