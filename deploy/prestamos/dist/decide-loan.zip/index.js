"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/decide-loan.ts
var decide_loan_exports = {};
__export(decide_loan_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(decide_loan_exports);

// src/domain.ts
var import_lib_dynamodb2 = require("@aws-sdk/lib-dynamodb");

// src/shared.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var env = {
  natillerasTable: process.env.NATILLERAS_TABLE || "natillera-registration",
  recordsTable: process.env.NATILLERA_RECORDS_TABLE || "natillera-records",
  loansTable: process.env.LOAN_REQUESTS_TABLE || "natillera-loan-request",
  authorIndex: process.env.LOAN_AUTHOR_INDEX || "author-index",
  natilleraIndex: process.env.LOAN_NATILLERA_INDEX || "natillera-index",
  // Interés por cuota sobre el saldo, en puntos básicos (100 = 1 %), igual que el modo demo del front.
  rateBps: BigInt(process.env.LOAN_RATE_BPS || "100"),
  maxInstallments: Number(process.env.LOAN_MAX_INSTALLMENTS || "12")
};
var dynamo = import_lib_dynamodb.DynamoDBDocumentClient.from(new import_client_dynamodb.DynamoDBClient({ region: process.env.AWS_REGION }), {
  marshallOptions: { removeUndefinedValues: true }
});
var HttpError = class extends Error {
  constructor(statusCode, error, message) {
    super(message);
    this.statusCode = statusCode;
    this.error = error;
  }
};
var json = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(body)
});
var isProxy = () => process.env.INTEGRATION_MODE !== "vtl";
var withErrors = (fn) => async (event) => {
  let status;
  let body;
  try {
    const result = await fn(event);
    return isProxy() ? json(200, result) : result;
  } catch (error) {
    if (error instanceof HttpError) {
      status = error.statusCode;
      body = { error: error.error, message: error.message };
    } else {
      console.log("Unhandled error", error);
      status = 500;
      body = { error: "InternalError", message: "Unexpected error" };
    }
  }
  if (isProxy()) return json(status, body);
  throw new Error(`[${status}] ${JSON.stringify(body)}`);
};
var currentIdentity = (event) => {
  let username;
  let sub;
  if (isProxy()) {
    const authorizer = event?.requestContext?.authorizer ?? {};
    const claims = authorizer.jwt?.claims ?? authorizer.claims ?? {};
    username = claims.username ?? claims["cognito:username"];
    sub = claims.sub;
  } else {
    username = event?.auth?.username;
    sub = event?.auth?.sub;
  }
  if (typeof username !== "string" || !username) throw new HttpError(401, "Unauthorized", "Missing username claim");
  return { username, sub: typeof sub === "string" && sub ? sub : void 0 };
};
var parseBody = (event) => {
  if (!isProxy()) {
    return event?.body && typeof event.body === "object" && !Array.isArray(event.body) ? event.body : {};
  }
  if (!event?.body) return {};
  try {
    const raw = event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body;
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    throw new HttpError(400, "BadRequest", "Body must be valid JSON");
  }
};
var param = (event, name) => {
  const value = isProxy() ? event?.pathParameters?.[name] ?? event?.queryStringParameters?.[name] : event?.params?.[name];
  return typeof value === "string" && value ? value : void 0;
};

// src/domain.ts
var getNatillera = async (natilleraId) => {
  const { Item } = await dynamo.send(new import_lib_dynamodb2.GetCommand({ TableName: env.natillerasTable, Key: { natilleraId } }));
  return Item ?? null;
};
var decideLoan = async (username, requestId, body) => {
  if (!requestId) throw new HttpError(400, "BadRequest", "Missing requestId");
  if (typeof body.accepted !== "boolean") throw new HttpError(400, "BadRequest", "accepted must be true or false");
  const { Item } = await dynamo.send(new import_lib_dynamodb2.GetCommand({ TableName: env.loansTable, Key: { requestId } }));
  const loan = Item;
  const natillera = loan ? await getNatillera(loan.natilleraId) : null;
  if (!loan || !natillera || natillera.author !== username) throw new HttpError(404, "LoanRequestNotFound", "Loan request not found");
  if (loan.status !== "pending") throw new HttpError(409, "AlreadyDecided", `Loan request is already ${loan.status}`);
  if (!body.accepted) {
    try {
      await dynamo.send(
        new import_lib_dynamodb2.UpdateCommand({
          TableName: env.loansTable,
          Key: { requestId },
          UpdateExpression: "SET #s = :rejected, decidedAt = :now, decidedBy = :admin",
          ConditionExpression: "#s = :pending",
          ExpressionAttributeNames: { "#s": "status" },
          ExpressionAttributeValues: { ":rejected": "rejected", ":pending": "pending", ":now": (/* @__PURE__ */ new Date()).toISOString(), ":admin": username }
        })
      );
    } catch (error) {
      if (error?.name === "ConditionalCheckFailedException") throw new HttpError(409, "AlreadyDecided", "Loan request was already decided");
      throw error;
    }
    return { status: "rejected" };
  }
  if (!loan.repaymentAuthorized) throw new HttpError(409, "RepaymentNotAuthorized", "The borrower has not authorized the installments yet");
  throw new HttpError(501, "DisbursementNotAvailable", "Loan disbursement (Open Payments) is not deployed yet");
};

// src/decide-loan.ts
var handler = withErrors(
  async (event) => decideLoan(currentIdentity(event).username, param(event, "requestId"), parseBody(event))
);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
