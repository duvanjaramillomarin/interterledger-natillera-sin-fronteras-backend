"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/list-loan-requests.ts
var list_loan_requests_exports = {};
__export(list_loan_requests_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(list_loan_requests_exports);

// src/domain.ts
var import_lib_dynamodb2 = require("@aws-sdk/lib-dynamodb");

// src/shared.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var env = {
  natillerasTable: process.env.NATILLERAS_TABLE || "natillera-registration",
  recordsTable: process.env.NATILLERA_RECORDS_TABLE || "natillera-records",
  loansTable: process.env.LOAN_REQUESTS_TABLE || "natillera-loan-request",
  authorIndex: process.env.LOAN_AUTHOR_INDEX || "author-index",
  natilleraIndex: process.env.LOAN_NATILLERA_INDEX || "natillera-index",
  // Interés por cuota sobre el saldo, en puntos básicos (100 = 1 %), igual que el modo demo del front.
  rateBps: BigInt(process.env.LOAN_RATE_BPS || "100"),
  maxInstallments: Number(process.env.LOAN_MAX_INSTALLMENTS || "12")
};
var dynamo = import_lib_dynamodb.DynamoDBDocumentClient.from(new import_client_dynamodb.DynamoDBClient({ region: process.env.AWS_REGION }), {
  marshallOptions: { removeUndefinedValues: true }
});
var HttpError = class extends Error {
  constructor(statusCode, error, message) {
    super(message);
    this.statusCode = statusCode;
    this.error = error;
  }
};
var json = (statusCode, body) => ({
  statusCode,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(body)
});
var isProxy = () => process.env.INTEGRATION_MODE !== "vtl";
var withErrors = (fn) => async (event) => {
  let status;
  let body;
  try {
    const result = await fn(event);
    return isProxy() ? json(200, result) : result;
  } catch (error) {
    if (error instanceof HttpError) {
      status = error.statusCode;
      body = { error: error.error, message: error.message };
    } else {
      console.log("Unhandled error", error);
      status = 500;
      body = { error: "InternalError", message: "Unexpected error" };
    }
  }
  if (isProxy()) return json(status, body);
  throw new Error(`[${status}] ${JSON.stringify(body)}`);
};
var currentIdentity = (event) => {
  let username;
  let sub;
  if (isProxy()) {
    const authorizer = event?.requestContext?.authorizer ?? {};
    const claims = authorizer.jwt?.claims ?? authorizer.claims ?? {};
    username = claims.username ?? claims["cognito:username"];
    sub = claims.sub;
  } else {
    username = event?.auth?.username;
    sub = event?.auth?.sub;
  }
  if (typeof username !== "string" || !username) throw new HttpError(401, "Unauthorized", "Missing username claim");
  return { username, sub: typeof sub === "string" && sub ? sub : void 0 };
};
var param = (event, name) => {
  const value = isProxy() ? event?.pathParameters?.[name] ?? event?.queryStringParameters?.[name] : event?.params?.[name];
  return typeof value === "string" && value ? value : void 0;
};

// src/domain.ts
var findNatillerasOf = async (username) => {
  const items = [];
  let ExclusiveStartKey;
  do {
    const page = await dynamo.send(
      new import_lib_dynamodb2.ScanCommand({
        TableName: env.natillerasTable,
        FilterExpression: "contains(integrants, :u)",
        ExpressionAttributeValues: { ":u": username },
        ExclusiveStartKey
      })
    );
    items.push(...page.Items ?? []);
    ExclusiveStartKey = page.LastEvaluatedKey;
  } while (ExclusiveStartKey);
  return items;
};
var toRequest = (i) => ({
  requestId: i.requestId,
  natilleraId: i.natilleraId,
  requesterName: i.author,
  amount: i.amount,
  installments: i.installments,
  repaymentAuthorized: Boolean(i.repaymentAuthorized),
  status: i.status,
  createdAt: i.createdAt
});
var queryLoans = async (indexName, field, value) => {
  const items = [];
  let ExclusiveStartKey;
  do {
    const page = await dynamo.send(
      new import_lib_dynamodb2.QueryCommand({
        TableName: env.loansTable,
        IndexName: indexName,
        KeyConditionExpression: `${field} = :v`,
        ExpressionAttributeValues: { ":v": value },
        ExclusiveStartKey
      })
    );
    items.push(...page.Items ?? []);
    ExclusiveStartKey = page.LastEvaluatedKey;
  } while (ExclusiveStartKey);
  return items.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
};
var listPendingRequests = async (username, natilleraId) => {
  const admined = (await findNatillerasOf(username)).filter((n) => n.author === username && (!natilleraId || n.natilleraId === natilleraId));
  const lists = await Promise.all(admined.map((n) => queryLoans(env.natilleraIndex, "natilleraId", n.natilleraId)));
  return lists.flat().filter((i) => i.status === "pending").sort((a, b) => a.createdAt.localeCompare(b.createdAt)).map(toRequest);
};

// src/list-loan-requests.ts
var handler = withErrors(async (event) => listPendingRequests(currentIdentity(event).username, param(event, "natilleraId")));
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
